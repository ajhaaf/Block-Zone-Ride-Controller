/* ==============================================================================
 * Project: Amusement Ride Block-Zone Safety & Autonomous Dispatch System
 * Role Alignment: Ride Systems Controls Automation Engineer
 * Target Platform: ESP32 (Wokwi & Arduino Core 3.x Compatible)
 * ==============================================================================
 */

#ifndef USE_WEBSERVER
#define USE_WEBSERVER 0
#endif

#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/event_groups.h"
#include "freertos/semphr.h"
#include "driver/gpio.h"
#include "driver/ledc.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_attr.h"

#if USE_WEBSERVER
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "nvs_flash.h"
#include "esp_http_server.h"

#define WIFI_SSID       "Wokwi-GUEST"
#define WIFI_PASS       ""
#endif

// ==============================================================================
// PIN DEFINITIONS & LEDC SERVO CONFIG
// ==============================================================================
#define BUTTON_ESTOP_GPIO    GPIO_NUM_18 // Physical E-Stop Mushroom Button (Active LOW)
#define BUTTON_DISPATCH_GPIO GPIO_NUM_19 // Station Dispatch Button (Active LOW)
#define PIN_SERVO_BRAKE_GPIO GPIO_NUM_13 // PWM Output to Servo (Brake Fin / Gate)

#define SERVO_LEDC_SPEED_MODE   LEDC_LOW_SPEED_MODE
#define SERVO_LEDC_CHANNEL      LEDC_CHANNEL_0
#define SERVO_LEDC_TIMER        LEDC_TIMER_0
#define SERVO_LEDC_DUTY_RES     LEDC_TIMER_14_BIT // 14-bit resolution (0-16383)

static const char *TAG = "RIDE_SAFETY";

// Ride Telemetry Structure
typedef struct {
    uint32_t timestamp_ms;
    uint32_t frame_id;
    int32_t  vehicle_speed_m_s;   /* Vehicle speed in mm/s */
    uint16_t block_zone_id;       /* 1 = Station, 2 = Lift Hill, 3 = Main Circuit */
    bool     restraints_locked;   /* Safety interlock flag */
} ride_telemetry_frame_t;

/* ---------- IPC Objects ---------- */
static QueueHandle_t      data_q; 
static EventGroupHandle_t evt_group;
static TaskHandle_t       responder_handle;
static TaskHandle_t       coordinator_handle_ref = NULL;

/* Event-group bit definitions for Block-Zone Interlocks */
#define EV_BIT_DATA_PRODUCED   (1 << 0) // Sensor data collected
#define EV_BIT_DATA_PROCESSED  (1 << 1) // Zone safety verifications cleared
#define EV_BIT_FAULT_INJECTED  (1 << 2) // Fault condition override active

/* Observability Heartbeats & Metrics */
static volatile uint32_t hb_prod  = 0;
static volatile uint32_t hb_cons  = 0;
static volatile uint32_t hb_coord = 0;
static volatile uint32_t hb_resp  = 0;

static ride_telemetry_frame_t last_consumed_frame;
static volatile uint32_t       total_dropped_frames = 0;
static volatile int64_t        last_isr_latency_us  = 0;

// System Safety State Flags
static bool g_brake_engaged = true;  // Current physical servo state (true = 0°, false = 90°)
static bool g_estop_latched = false; // System safety trip flag (true = Latched E-Stop)

// ==============================================================================
// NATIVE ESP-IDF LEDC SERVO FUNCTIONS
// ==============================================================================

/**
 * Maps servo angle (0 to 180 degrees) to 50Hz LEDC PWM duty cycle.
 * Standard 50Hz Servo @ 14-bit (16384 ticks per 20ms frame):
 * - 0 degrees   (~0.5ms pulse)  = ~410 ticks
 * - 180 degrees (~2.5ms pulse)  = ~2048 ticks
 */
void set_servo_angle(uint32_t angle_deg) {
    uint32_t duty = 410 + ((angle_deg * (2048 - 410)) / 180);
    ledc_set_duty(SERVO_LEDC_SPEED_MODE, SERVO_LEDC_CHANNEL, duty);
    ledc_update_duty(SERVO_LEDC_SPEED_MODE, SERVO_LEDC_CHANNEL);
}

void init_servo_pwm() {
    // 1. Configure LEDC Timer
    ledc_timer_config_t ledc_timer = {
        .speed_mode       = SERVO_LEDC_SPEED_MODE,
        .duty_resolution  = SERVO_LEDC_DUTY_RES,
        .timer_num        = SERVO_LEDC_TIMER,
        .freq_hz          = 50, // 50Hz Servo Standard
        .clk_cfg          = LEDC_AUTO_CLK
    };
    ledc_timer_config(&ledc_timer);

    // 2. Configure LEDC Channel on GPIO 13
    ledc_channel_config_t ledc_channel = {
        .gpio_num       = PIN_SERVO_BRAKE_GPIO,
        .speed_mode     = SERVO_LEDC_SPEED_MODE,
        .channel        = SERVO_LEDC_CHANNEL,
        .intr_type      = LEDC_INTR_DISABLE,
        .timer_sel      = SERVO_LEDC_TIMER,
        .duty           = 0,
        .hpoint         = 0
    };
    ledc_channel_config(&ledc_channel);

    // Initial State: 0 degrees (Brakes engaged at startup)
    set_servo_angle(0);
    g_brake_engaged = true;
}

// ==============================================================================
// INTERRUPT SERVICE ROUTINES (ISRs)
// ==============================================================================
static volatile int64_t last_edge_us = 0;
static volatile int64_t last_dispatch_us = 0;

static void IRAM_ATTR button_estop_isr(void *arg)
{
    int64_t now = esp_timer_get_time();
    if (now - last_edge_us < 200000) return; // 200ms debounce
    last_edge_us = now;
    last_isr_latency_us = now;

    BaseType_t woken = pdFALSE;
    vTaskNotifyGiveFromISR(responder_handle, &woken);
}
static void IRAM_ATTR button_dispatch_isr(void *arg)
{
    int64_t now = esp_timer_get_time();
    if (now - last_dispatch_us < 300000) return; // 300ms debounce
    last_dispatch_us = now;

    if (coordinator_handle_ref != NULL) {
        BaseType_t woken = pdFALSE;
        vTaskNotifyGiveFromISR(coordinator_handle_ref, &woken);
        portYIELD_FROM_ISR(woken);
    }
}

// ==============================================================================
// REAL-TIME CORE 1 TASKS
// ==============================================================================

/* Producer Task: Generates telemetry frames at 20 Hz */
static void producer_task(void *arg)
{
    ride_telemetry_frame_t frame;
    uint32_t frame_counter = 0;
    ESP_LOGI(TAG, "[PROD] Track Sensor & Speed Telemetry Pipeline Started at 20 Hz");

    for (;;) {
        frame.timestamp_ms = (uint32_t)(esp_timer_get_time() / 1000);
        frame.frame_id     = ++frame_counter;
        
        // Simulating train movement through Block Zones
        frame.block_zone_id     = (frame_counter / 50) % 3 + 1;
        frame.vehicle_speed_m_s = 1500 + (frame_counter % 20) * 100; // mm/s
        frame.restraints_locked = g_brake_engaged;

        /* Back-pressure Policy: Block up to 5 ms; drop frame if queue full */
        if (xQueueSend(data_q, &frame, pdMS_TO_TICKS(5)) != pdTRUE) {
            total_dropped_frames++;
            ESP_LOGW(TAG, "[PROD] Queue FULL! Dropping Frame #%lu (Total Dropped: %lu)",
                     (unsigned long)frame.frame_id, (unsigned long)total_dropped_frames);
        } else {
            xEventGroupSetBits(evt_group, EV_BIT_DATA_PRODUCED);
        }

        hb_prod++;
        vTaskDelay(pdMS_TO_TICKS(50)); /* 20 Hz periodic telemetry */
    }
}

/* Consumer Task: Analyzes telemetry and checks overspeed interlocks */
static void consumer_task(void *arg)
{
    ride_telemetry_frame_t rx_frame;
    ESP_LOGI(TAG, "[CONS] Safety Analysis & Block Occupancy Engine Started");

    for (;;) {
        if (xQueueReceive(data_q, &rx_frame, portMAX_DELAY) == pdTRUE) {
            last_consumed_frame = rx_frame;
             //INDUCE DEGRADATION: Slow consumer down from 10ms to 100ms
            vTaskDelay(pdMS_TO_TICKS(100));

            /* Automated Overspeed Check (> 3.2 m/s) */
            if (rx_frame.vehicle_speed_m_s > 3200) {
                ESP_LOGE(TAG, "[CONS] OVERSPEED FAULT! Zone %u Speed: %ld mm/s", 
                         rx_frame.block_zone_id, (long)rx_frame.vehicle_speed_m_s);
                xEventGroupSetBits(evt_group, EV_BIT_FAULT_INJECTED);
            }

            vTaskDelay(pdMS_TO_TICKS(10)); // Signal processing window
            xEventGroupSetBits(evt_group, EV_BIT_DATA_PROCESSED);
            hb_cons++;
        }
    }
}

/* Coordinator Task: Synchronizes event pipeline AND handles non-blocking dispatch triggers */
static void coordinator_task(void *arg)
{
    coordinator_handle_ref = xTaskGetCurrentTaskHandle();
    const EventBits_t wait_mask = EV_BIT_DATA_PRODUCED | EV_BIT_DATA_PROCESSED;
    ESP_LOGI(TAG, "[COORD] Block-Zone Safety Interlock Coordinator Active");

    for (;;) {
        // 1. Process Event Pipeline Sync (50ms timeout)
        EventBits_t got = xEventGroupWaitBits(evt_group, wait_mask,
                                              pdTRUE, pdTRUE, pdMS_TO_TICKS(50));
        if ((got & wait_mask) == wait_mask) {
            hb_coord++;
        }

        // 2. Poll Dispatch / Reset Request
        uint32_t dispatch_req = ulTaskNotifyTake(pdTRUE, 0);

        if (dispatch_req > 0) {

            // --- CASE A: SYSTEM IS IN LATCHED E-STOP (ATTEMPT SAFETY RESET) ---
            if (g_estop_latched) {
                ESP_LOGW(TAG, "[RESET] Attempting Safety Reset... Hold GPIO 19 for 2s...");
                
                // Read pin state directly to verify a 2-second hold (Active LOW)
                int hold_counter = 0;
                while (gpio_get_level(BUTTON_DISPATCH_GPIO) == 0) {
                    vTaskDelay(pdMS_TO_TICKS(100));
                    hold_counter++;
                    if (hold_counter >= 20) { // 20 * 100ms = 2.0 seconds
                        break;
                    }
                }

                if (hold_counter >= 20) {
                    // CLEAR THE LATCHED E-STOP
                    g_estop_latched = false;
                    xEventGroupClearBits(evt_group, EV_BIT_FAULT_INJECTED);
                    ESP_LOGI(TAG, "[RESET SUCCESS] E-STOP Cleared! Safety Interlocks Restored (Servo at 0° READY).");
                } else {
                    ESP_LOGE(TAG, "[RESET REJECTED] Reset hold aborted. Button released too early.");
                }
                continue;
            }

            // --- CASE B: NORMAL DISPATCH SEQUENCE (E-STOP CLEARED) ---
            if (last_consumed_frame.block_zone_id == 2) {
                ESP_LOGW(TAG, "[DISPATCH REJECTED] Down-track Block Zone 2 is OCCUPIED!");
                continue;
            }

            ESP_LOGI(TAG, "[DISPATCH CLEARED] Releasing Brake Fin (Servo -> 90°)");
            
            // 1. Open Brake Fin (0° -> 90°)
            set_servo_angle(90);
            g_brake_engaged = false;

            // 2. Train Exit Hold Window (2.5 seconds)
            vTaskDelay(pdMS_TO_TICKS(2500));

            // 3. Reset Brake Fin to Home Safe State (90° -> 0°)
            set_servo_angle(0);
            g_brake_engaged = true;
            ESP_LOGI(TAG, "[DISPATCH COMPLETE] Train cleared station. Servo returned to 0°");
        }
    }
}


/* Responder Task: Direct Task Notification Handler for Hard E-STOP */
static void responder_task(void *arg)
{
    ESP_LOGI(TAG, "[RESP] Emergency Actuator & Safety Responder Ready");

    for (;;) {
        uint32_t notify_count = ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        int64_t unblock_time = esp_timer_get_time();

        if (notify_count > 0 && last_isr_latency_us > 0) {
            int64_t latency = unblock_time - last_isr_latency_us;
            
            // Force hardware safe state (Servo -> 0°)
            set_servo_angle(0);
            g_brake_engaged = true;
            g_estop_latched = true;

            // Set global event group fault bit
            xEventGroupSetBits(evt_group, EV_BIT_FAULT_INJECTED);

            ESP_LOGE(TAG, "[RESP] *** HARD E-STOP LATCHED *** Latency: %lld us | Servo -> 0°", latency);
            last_isr_latency_us = 0;
            hb_resp++;
        }
    }
}

// ==============================================================================
// OBSERVABILITY PLANE (CORE 0)
// ==============================================================================

#if USE_WEBSERVER
static esp_err_t root_http_handler(httpd_req_t *req)
{
    UBaseType_t depth = uxQueueMessagesWaiting(data_q);
    EventBits_t bits  = xEventGroupGetBits(evt_group);

    char resp_str[1024];
    snprintf(resp_str, sizeof(resp_str),
        "<!DOCTYPE html><html><head><title>Ride Control Observability Console</title>"
        "<meta http-equiv='refresh' content='1'>"
        "<style>"
        "body { font-family: monospace; background: #0f172a; color: #38bdf8; padding: 20px; }"
        ".card { border: 1px solid #38bdf8; padding: 15px; margin-bottom: 15px; background: #1e293b; border-radius: 6px; }"
        "h2 { color: #f8fafc; margin-top: 0; }"
        "span.val { color: #4ade80; font-weight: bold; }"
        "span.warn { color: #f87171; font-weight: bold; }"
        "</style></head><body>"
        "<h1>Coaster Block-Zone Control Console (Core 0)</h1>"
        "<div class='card'>"
        "<h2>Track Dynamics & Servo Actuator</h2>"
        "<p>Queue Utilization: <span class='val'>%u / 16</span></p>"
        "<p>Brake Fin Servo Status: <span class='%s'>%s</span></p>"
        "<p>Active Zone: <span class='val'>Zone %u</span> | Speed: <span class='val'>%.2f m/s</span></p>"
        "</div>"
        "<div class='card'>"
        "<h2>Interlock Bitmask (evt_group)</h2>"
        "<p>Bit Register: <span class='val'>0x%02X</span> (PRODUCED: %s | PROCESSED: %s | FAULT: <span class='%s'>%s</span>)</p>"
        "</div>"
        "<div class='card'>"
        "<h2>Task Heartbeats (Core 1)</h2>"
        "<p>Producer HB: <span class='val'>%lu</span> | Consumer HB: <span class='val'>%lu</span></p>"
        "<p>Coord HB: <span class='val'>%lu</span> | Responder HB: <span class='val'>%lu</span></p>"
        "</div>"
        "</body></html>",
        (unsigned)depth,
        g_brake_engaged ? "warn" : "val",
        g_brake_engaged ? "ENGAGED (0°)" : "RELEASED (90°)",
        (unsigned)last_consumed_frame.block_zone_id,
        ((float)last_consumed_frame.vehicle_speed_m_s) / 1000.0f,
        (unsigned)bits,
        (bits & EV_BIT_DATA_PRODUCED)  ? "1" : "0",
        (bits & EV_BIT_DATA_PROCESSED) ? "1" : "0",
        (bits & EV_BIT_FAULT_INJECTED) ? "warn" : "val",
        (bits & EV_BIT_FAULT_INJECTED) ? "ACTIVE" : "NONE",
        (unsigned long)hb_prod, (unsigned long)hb_cons,
        (unsigned long)hb_coord, (unsigned long)hb_resp
    );

    httpd_resp_set_type(req, "text/html");
    httpd_resp_send(req, resp_str, HTTPD_RESP_USE_STRLEN);
    return ESP_OK;
}

static void wifi_init_sta(void)
{
    ESP_ERROR_CHECK(nvs_flash_init());
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    esp_netif_create_default_wifi_sta();
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    wifi_config_t wifi_config = {};
    strcpy((char*)wifi_config.sta.ssid, WIFI_SSID);
    strcpy((char*)wifi_config.sta.password, WIFI_PASS);

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());
    ESP_ERROR_CHECK(esp_wifi_connect());
    ESP_LOGI(TAG, "Connecting to Wi-Fi SSID: %s...", WIFI_SSID);
}

static void start_webserver(void)
{
    httpd_handle_t server = NULL;
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = 80;

    httpd_uri_t root_uri = {
        .uri       = "/",
        .method    = HTTPGET,
        .handler   = root_http_handler,
        .user_ctx  = NULL
    };

    if (httpd_start(&server, &config) == ESP_OK) {
        httpd_register_uri_handler(server, &root_uri);
        ESP_LOGI(TAG, "Web Observability Console active on port 80");
    }
}

static void webmonitor_task(void *arg)
{
    wifi_init_sta();
    vTaskDelay(pdMS_TO_TICKS(3000));
    start_webserver();

    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

#else

static void serial_monitor_task(void *arg)
{
    for (;;) {
        UBaseType_t depth = uxQueueMessagesWaiting(data_q);
        EventBits_t bits  = xEventGroupGetBits(evt_group);
        ESP_LOGI(TAG,
                 "[MONITOR-CORE0] q_depth=%u/16 | zone=%u | speed=%.2fm/s | Servo=%s | HB [P=%lu C=%lu Co=%lu R=%lu]",
                 (unsigned)depth, 
                 (unsigned)last_consumed_frame.block_zone_id,
                 ((float)last_consumed_frame.vehicle_speed_m_s) / 1000.0f,
                 g_brake_engaged ? "0° (ENGAGED)" : "90° (RELEASED)",
                 (unsigned long)hb_prod, (unsigned long)hb_cons,
                 (unsigned long)hb_coord, (unsigned long)hb_resp);
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}
#endif

// ==============================================================================
// ARDUINO SETUP & MAIN ENTRY
// ==============================================================================
void setup() 
{
    esp_log_level_set(TAG, ESP_LOG_INFO);
    ESP_LOGI(TAG, "==== Ride Control Block-Zone Safety System Initializing ====");

    // Initialize LEDC PWM for Servo Motor on GPIO 13
    init_servo_pwm();

    // Create IPC Queues and Semaphores
    data_q = xQueueCreate(16, sizeof(ride_telemetry_frame_t));
    configASSERT(data_q);

    evt_group = xEventGroupCreate();
    configASSERT(evt_group);

    // Create Real-Time Tasks (Core 1)
    xTaskCreatePinnedToCore(producer_task,    "prod",   4096, NULL,  8, NULL, APP_CPU_NUM);
    xTaskCreatePinnedToCore(consumer_task,    "cons",   4096, NULL,  8, NULL, APP_CPU_NUM);
    xTaskCreatePinnedToCore(coordinator_task, "coord",  4096, NULL,  9, NULL, APP_CPU_NUM);
    xTaskCreatePinnedToCore(responder_task,   "resp",   4096, NULL, 12, &responder_handle, APP_CPU_NUM);

    // Create Observability Task (Core 0)
#if USE_WEBSERVER
    xTaskCreatePinnedToCore(webmonitor_task,    "webmon",  4096, NULL, 4, NULL, PRO_CPU_NUM);
#else
    xTaskCreatePinnedToCore(serial_monitor_task, "monitor", 4096, NULL, 4, NULL, PRO_CPU_NUM);
#endif

    // E-STOP Button GPIO 18 Setup
    gpio_config_t btn_cfg = {
        .pin_bit_mask = (1ULL << BUTTON_ESTOP_GPIO),
        .mode         = GPIO_MODE_INPUT,
        .pull_up_en   = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type    = GPIO_INTR_NEGEDGE
    };
    gpio_config(&btn_cfg);

    // Dispatch Button GPIO 19 Setup
    gpio_config_t dispatch_cfg = {
        .pin_bit_mask = (1ULL << BUTTON_DISPATCH_GPIO),
        .mode         = GPIO_MODE_INPUT,
        .pull_up_en   = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type    = GPIO_INTR_NEGEDGE
    };
    gpio_config(&dispatch_cfg);

    // Install Shared Interrupt Handlers
    gpio_install_isr_service(0);
    gpio_isr_handler_add(BUTTON_ESTOP_GPIO, button_estop_isr, NULL);
    gpio_isr_handler_add(BUTTON_DISPATCH_GPIO, button_dispatch_isr, NULL);

    ESP_LOGI(TAG, "Ride safety system operational.");
    ESP_LOGI(TAG, "How to Test in Wokwi:");
    ESP_LOGI(TAG, "1. Press GPIO 18 (E-STOP) to clear brake state (Servo moves to 90°).");
    ESP_LOGI(TAG, "2. Press GPIO 19 (DISPATCH) to dispatch train (Servo sweeps 90° -> 2.5s -> 0°).");
}

void loop() 
{
    vTaskDelay(pdMS_TO_TICKS(1000));
}